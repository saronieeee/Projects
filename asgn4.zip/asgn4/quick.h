/*
* DO NOT MODIFY THIS FILE
*/

#pragma once

#include "stats.h"

void quick_sort(Stats *stats, int *A, int n);
