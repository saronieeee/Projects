/*
* DO NOT MODIFY THIS FILE
*/

#pragma once

#include "stats.h"

void insertion_sort(Stats *stats, int *arr, int length);
