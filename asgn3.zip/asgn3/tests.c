#include "mathlib.h"
#include "messages.h"
#include "operators.h"
#include "stack.h"

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define STACK_CAPACITY 64

int main() {
    char expr[STACK_CAPACITY];

    while (1) {
        printf("> ");
        if (fgets(expr, STACK_CAPACITY, stdin) == NULL) {
            // Handle end-of-file (e.g., Ctrl+D) to exit the program
            printf("Exiting...\n");
            exit(0);
        }
        stack_clear();
        char *saveptr;
        const char *token = strtok_r(expr, " ", &saveptr);

        while (token != NULL) {
            double value;
            if (parse_double(token, &value)) {
                // If the token is a number, push it onto the stack
                stack_push(value);
            } else {
                binary_operator_fn binary_op
                    = binary_operators[(unsigned char) token[0]]; // Use character code as an index

                if (binary_op != NULL) {
                    if (stack_size < 2) {
                        fprintf(stderr, ERROR_BINARY_OPERATOR);
                    } else {
                        double result;
                        double operand;
                        stack_pop(&operand);
                        stack_pop(&result);
                        result = binary_op(result, operand);
                        printf("result: %f\n", result);
                        // Push the result back onto the stack
                        stack_push(result);
                    }
                }
            }

            token = strtok_r(NULL, " ", &saveptr);
        }
    }

    return 0;
}
