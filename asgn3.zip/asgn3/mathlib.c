#include "mathlib.h"

#include <math.h>
#include <stdio.h>

double Abs(double x) {
    if (x > 0) {
        return x;
    } else {
        return x *= -1;
    }
}

double Sqrt(double x) {
    // check domain
    if (x < 0) {
        return nan("nan");
    }

    double old = 0.0;
    double new = 1.0;

    while (Abs(old - new) > EPSILON) {
        // specifically, this is the Babylonian method
        // -- a simplification of Newton's method possible
        // only for sqrt(x).
        old = new;
        new = 0.5 * (old + (x / old));
    }

    return new;
}

double Sin(double x) {

    x = fmod(x, 2 * M_PI);

    int n = 1;
    double product = x;
    double sum = 0.0;

    while (fabs(product) > EPSILON) {

        sum += product;
        n += 2;
        product *= -1 * x * x / (n * (n - 1));
    }
    return sum;
}

double Cos(double x) {
    x = fmod(x, 2 * M_PI);

    int n = 2;
    double product = 1.0;
    double sum = 1.0;

    while (fabs(product) > EPSILON) {

        product *= -1 * x * x / (n * (n - 1));
        sum += product;
        n += 2;
    }
    return sum;
}
double Tan(double x) {
    return Sin(x) / Cos(x);
}
