#include "bmp.h"
#include "io.h"

#include <getopt.h>
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define OPTIONS "o:i:h"
#define HELP                                                                                       \
    "Usage: colorb -i infile -o outfile\n"                                                         \
    "       colorb -h\n"
int main(int argc, char **argv) {
    //switch case for -i, -o, -d, -h
    int opt;
    char *filein;
    char *fileout;
    FILE *inputFile;
    FILE *outputFile;
    while ((opt = getopt(argc, argv, OPTIONS)) != -1) {
        switch (opt) {
        case 'i': //sets file input
            filein = optarg;
            break;
        case 'o': //sets file output
            fileout = optarg;
            break;
        case 'h': fprintf(stdout, "%s", HELP); exit(0);
        default: fprintf(stderr, "%s", HELP); exit(1);
        }
    }

    //printf("%s %s",filein, fileout);
    if (filein != NULL && fileout != NULL) {
        inputFile = fopen(filein, "rb");
        if (inputFile == NULL) {
            fprintf(stderr, "colorb: error opening input file %s\n", filein);
            fprintf(stderr, "%s", HELP);
            exit(1);
        }
        outputFile = fopen(fileout, "wb");
        if (inputFile == NULL) {
            fprintf(stderr, "colorb: error opening output file %s\n", filein);
            fprintf(stderr, "%s", HELP);
            exit(1);
        }
    } else if (filein == NULL) {
        fprintf(stderr, "colorb:  -i option is required\n");
        fprintf(stderr, "%s", HELP);
        exit(1);
    } else {
        fprintf(stderr, "colorb:  -o option is required\n");
        fprintf(stderr, "%s", HELP);
        exit(1);
    }

    BMP *bmp = bmp_create(inputFile);
    bmp_reduce_palette(bmp);
    bmp_write(bmp, outputFile);
    bmp_free(&bmp);

    fclose(inputFile);
    fclose(outputFile);
}
