#include "bitreader.h"
#include "bitwriter.h"
#include "node.h"
#include "pq.h"

#include <getopt.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define OPTIONS "i:o:h"
#define HELP                                                                                       \
    "Usage: huff -i infile -o outfile\n"                                                           \
    "       huff -v -i infile -o outfile\n"                                                        \
    "       huff -h\n"

typedef struct Code {
    uint64_t code;
    uint8_t code_length;
} Code;

uint32_t fill_histogram(FILE *fin, uint32_t *histogram) {
    // Clear all elements of the histogram array
    for (uint32_t i = 0; i < 256; i++) {
        histogram[i] = 0;
    }

    uint32_t filesize = 0;
    int byte;

    // Read bytes from fin using fgetc()
    while ((byte = fgetc(fin)) != EOF) {
        // Increment the proper element of the histogram
        ++histogram[byte];
        ++filesize;
    }

    // Important Hack: Ensure at least two values of the histogram array are non-zero
    ++histogram[0x00];
    ++histogram[0xff];
    // Return the total size of the file
    return filesize;
}

Node *create_tree(uint32_t *histogram, uint16_t *num_leaves) {
    PriorityQueue *pq = pq_create();
    *num_leaves = 0;

    for (uint16_t i = 0; i < 256; i++) {
        if (histogram[i] > 0) {
            Node *new_node = node_create((uint8_t) i, histogram[i]);
            enqueue(pq, new_node);
            (*num_leaves)++;
        }
    }

    //pq_print(pq);

    while (!pq_size_is_1(pq)) {
        Node *left = dequeue(pq);
        Node *right = dequeue(pq);

        Node *n = node_create(0, left->weight + right->weight);
        n->left = left;
        n->right = right;

        enqueue(pq, n);
    }

    //pq_print(pq);
    Node *huffman_tree = dequeue(pq);
    node_print_tree(huffman_tree);
    pq_free(&pq);

    //printf("num leaves: %u\n", *num_leaves);
    //node_print_tree(huffman_tree);

    return huffman_tree;
}

void fill_code_table(Code *code_table, Node *node, uint64_t code, uint8_t code_length) {

    if (node->left != NULL && node->right != NULL) {
        fill_code_table(code_table, node->left, code, code_length + 1);
        code |= (uint64_t) 1 << code_length;
        fill_code_table(code_table, node->right, code, code_length + 1);
        //printf("code: %lu, code_length: %u\n", code, code_length);
        //node_print_tree(node);
    } else {
        code_table[node->symbol].code = code;
        code_table[node->symbol].code_length = code_length;
    }
}

//saronieeeee macaronieeeee
void huff_write_tree(BitWriter *outbuf, Node *node) {
    if (node->left == NULL && node->right == NULL) {
        //node is a leaf
        bit_write_bit(outbuf, 1);
        bit_write_uint8(outbuf, node->symbol);
    } else {
        //node is internal
        huff_write_tree(outbuf, node->left);
        huff_write_tree(outbuf, node->right);
        bit_write_bit(outbuf, 0);
    }
}

void huff_compress_file(BitWriter *outbuf, FILE *fin, uint32_t filesize, uint16_t num_leaves,
    Node *code_tree, Code *code_table) {
    bit_write_uint8(outbuf, 'H');
    bit_write_uint8(outbuf, 'C');
    bit_write_uint32(outbuf, filesize);
    bit_write_uint16(outbuf, num_leaves);
    huff_write_tree(outbuf, code_tree);
    int b;
    while (1) {
        b = fgetc(fin);
        if (b == EOF) {
            break;
        }
        uint64_t code = code_table[b].code;
        uint8_t code_length = code_table[b].code_length;
        for (uint8_t i = 0; i < code_length; i++) {
            bit_write_bit(outbuf, (code & 1));
            code >>= 1;
        }
    }
}

int main(int argc, char **argv) {
    int opt;
    char *filein;
    char *fileout;
    FILE *inputFile = NULL;

    while ((opt = getopt(argc, argv, OPTIONS)) != -1) {
        switch (opt) {
        case 'i': //sets file input
            filein = optarg;
            break;
        case 'o': fileout = optarg; break;
        case 'h': fprintf(stdout, "%s", HELP); exit(0);
        default: fprintf(stderr, "%s", HELP); exit(1);
        } //end of switch case
    } // end of opt loop

    //Step 1 in Huffman Coding - fill histogram with code frequencies
    inputFile = fopen(filein, "rb");
    uint32_t histogram[256] = { 0 };
    uint32_t filesize = fill_histogram(inputFile, histogram);
    rewind(inputFile);

    //Step 2 - create code tree
    uint16_t num_leaves = 0;
    Node *codeTree = create_tree(histogram, &num_leaves);

    //Step 3 - fill 256-entry code table
    Code codeTable[256];
    fill_code_table(codeTable, codeTree, 0, 0);

    //Step 5 - create huffman coded output file forom input file
    BitWriter *outbuf = bit_write_open(fileout);
    huff_compress_file(outbuf, inputFile, filesize, num_leaves, codeTree, codeTable);

    //Free memory
    fclose(inputFile);
    bit_write_close(&outbuf);
    node_free(&codeTree);
    //free all memory
    //pq_free(pq);
    //

} // end of main function
