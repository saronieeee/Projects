#include "bitreader.h"

#include <stdio.h>
#include <stdlib.h>

struct BitReader {
    FILE *underlying_stream;
    uint8_t byte;
    uint8_t bit_position;
};

BitReader *bit_read_open(const char *filename) {
    BitReader *bitreader = (BitReader *) calloc(1, sizeof(BitReader));
    FILE *f = fopen(filename, "rb");
    bitreader->underlying_stream = f;
    bitreader->byte = 0;
    bitreader->bit_position = 8;
    return bitreader;
}

void bit_read_close(BitReader **pbuf) {
    if (*pbuf != NULL) {
        fclose((*pbuf)->underlying_stream);
        free(*pbuf);
        *pbuf = NULL;
    }
}

uint8_t bit_read_bit(BitReader *buf) {
    if (buf->bit_position > 7) {
        buf->byte = (uint8_t) fgetc(buf->underlying_stream);
        buf->bit_position = 0;
    }
    uint8_t b = 0x01;
    uint8_t x = (uint8_t) (b << buf->bit_position);
    x = buf->byte & x;
    x = x >> buf->bit_position;
    buf->bit_position++;
    return x;
}

uint8_t bit_read_uint8(BitReader *buf) {
    uint8_t byte = 0x00;
    for (int i = 0; i < 8; i++) {
        byte |= (bit_read_bit(buf) << i);
    }
    return byte;
}

uint16_t bit_read_uint16(BitReader *buf) {
    uint16_t word = 0x0000;
    for (int i = 0; i < 16; i++) {
        word |= (bit_read_bit(buf) << i);
    }
    return word;
}
uint32_t bit_read_uint32(BitReader *buf) {
    uint32_t word = 0x00000000;
    for (int i = 0; i < 32; i++) {
        word |= ((uint32_t) bit_read_bit(buf) << i);
    }
    return word;
}
