#include "pq.h"

#include <stdbool.h>
#include <stdio.h>

typedef struct ListElement ListElement;

struct ListElement {
    Node *tree;
    ListElement *next;
};

struct PriorityQueue {
    ListElement *list;
};

PriorityQueue *pq_create(void) {
    PriorityQueue *pq = (PriorityQueue *) malloc(sizeof(PriorityQueue));
    pq->list = NULL;
    return pq;
}

void pq_free(PriorityQueue **q) {
    if (*q != NULL) {
        free(*q);
        *q = NULL;
    }
}

bool pq_is_empty(PriorityQueue *q) {
    bool empty = (q->list == NULL || q == NULL) ? true : false;
    return empty;
}

bool pq_size_is_1(PriorityQueue *q) {
    return (q != NULL && q->list != NULL && q->list->next == NULL);
}

bool pq_less_than(ListElement *e1, ListElement *e2) {
    if (e1->tree->weight < e2->tree->weight) {
        return true;
    } else if (e1->tree->weight == e2->tree->weight) {
        if (e1->tree->symbol < e2->tree->symbol) {
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

void enqueue(PriorityQueue *q, Node *tree) {
    ListElement *new_element = (ListElement *) calloc(1, sizeof(ListElement));
    if (new_element == NULL) {
        fprintf(stderr, "Error: Unable to allocate memory for ListElement\n");
        exit(1);
    }

    new_element->tree = tree;
    new_element->next = NULL;

    if (pq_is_empty(q) || pq_less_than(new_element, q->list)) {
        // The queue is empty or the new element is smaller than the head
        new_element->next = q->list;
        q->list = new_element;
    } else {
        // Traverse the list to find the appropriate position
        ListElement *currentList = q->list;
        while (currentList->next != NULL && !pq_less_than(new_element, currentList->next)) {
            currentList = currentList->next;
        }
        // Insert the new element after currentList
        new_element->next = currentList->next;
        currentList->next = new_element;
    }
}

Node *dequeue(PriorityQueue *q) {
    if (q == NULL || q->list == NULL) {
        fprintf(stderr, "Error: Attempting to dequeue from an empty queue\n");
        exit(1);
    }

    Node *dequeuedNode = q->list->tree;
    ListElement *temp = q->list;
    q->list = q->list->next;
    free(temp);

    return dequeuedNode;
}

void pq_print(PriorityQueue *q) {
    assert(q != NULL);
    ListElement *e = q->list;
    int position = 1;
    while (e != NULL) {
        if (position++ == 1) {
            printf("=============================================\n");
        } else {
            printf("---------------------------------------------\n");
        }
        node_print_tree(e->tree);
        e = e->next;
    }
    printf("=============================================\n");
}
