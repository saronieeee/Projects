#include "batcher.h"
#include "gaps.h"
#include "heap.h"
#include "insert.h"
#include "quick.h"
#include "set.h"
#include "shell.h"
#include "stats.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define OPTIONS "aishqbr:n:p:H"
#define HELP                                                                                       \
    "Select at least one sort to perform.\nSYNOPSIS\n\t A collection of comparison-based sorting " \
    "algorithms.\n\nUSAGE\n\t./sorting [-Hahbsqi] [-n length] [-p elements] [-r "                  \
    "seed]\n\nOPTIONS\n\t-H\t\t\t\tDisplay program help and usage.\n\t-a\t\t\t\tEnable all "       \
    "sorts.\n\t-h\t\t\t\tEnable Heap Sort.\n\t-b\t\t\t\tEnable Batcher Sort.\n\t-s\t\t\t\tEnable " \
    "Shell Sort.\n\t-q\t\t\t\tEnable Quick Sort.\n\t-i\t\t\t\tEnable Insertion Sort.\n\t-n "       \
    "length\t\t\tSpecify number of array elements (default: 100).\n\t-p "                          \
    "elements\t\t\tSpecify number of elements to print (default: 100).\n\t-r "                     \
    "seed\t\t\t\tSpecify random seed (default: 13371453)."

void printSortedArray(int *A, int elements, int arrSize) {
    if (elements == 0) {
        return;
    }
    if (arrSize < elements) {
        for (int i = 0; i < arrSize; i++) {
            fprintf(stdout, "%13d", A[i]); // Use %10d for alignment
            if ((i + 1) % 5 == 0) {
                fprintf(stdout, "\n"); // Start a new line after every 5 elements
            }
        }
    } else {
        for (int i = 0; i < elements; i++) {
            fprintf(stdout, "%13d", A[i]); // Use %10d for alignment
            if ((i + 1) % 5 == 0) {
                fprintf(stdout, "\n"); // Start a new line after every 5 elements
            }
        }
    }
    if (arrSize < 5 || elements < 5) {
        fprintf(stdout, "\n");
    }
}

int main(int argc, char *argv[]) {

    Stats stats;
    int seed = 13371453;
    int arrSize = 100;
    int elements = 100;

    //printf("running\n");

    if (argc == 1) {
        fprintf(stderr, "%s\n", HELP);
    }

    int opt;
    Set setOptions = set_empty();
    while ((opt = getopt(argc, argv, OPTIONS)) != -1) {
        switch (opt) {
        case 'a': setOptions = 0x1F; break; //employs all sorting algorithms

        case 'i': setOptions = setOptions | 0x01; break; // enables insertion
        case 's': setOptions = setOptions | 0x01 << 1; break; // enables shell
        case 'h': setOptions = setOptions | 0x01 << 2; break; // enables heap
        case 'q': setOptions = setOptions | 0x01 << 3; break; // enables quicksort
        case 'b':
            setOptions = setOptions | 0x01 << 4;
            break; // enables batcher sort

        //change these to not be a part of set
        case 'r': seed = atoi(optarg); break; // set the random seed to seed
        case 'n':
            if (argc <= 3) {
                fprintf(stderr, "%s", HELP);
                exit(1);
            }
            arrSize = atoi(optarg);
            break;
        case 'p':
            //printf("%d",argc);
            if (argc <= 3) {
                fprintf(stderr, "%s", HELP);
                exit(1);
            }

            elements = atoi(optarg);
            //printf("change arraysize to %s\n", optarg);
            break;
        case 'H': fprintf(stderr, "%s", HELP); exit(1);
        default: fprintf(stderr, "%s", HELP); exit(1);
        }
    }

    //printf("%d %d %d\n\n",seed, arrSize,elements);
    //printf("%hhu\n",setOptions);

    //following code inspired by 11/3/23 lecture
    int *A = calloc(arrSize, sizeof(int));
    srandom(seed);
    for (int i = 0; i < arrSize; i++) {
        A[i] = random() & 0x3FFFFFFF;
    }

    //time to check which ones were selected and implement it
    //Set option_a = 0x1F; // all options
    Set option_i = 0x01; //insert sort
    Set option_s = 0x01 << 1;
    Set option_h = 0x01 << 2;
    Set option_q = 0x01 << 3;
    Set option_b = 0x01 << 4;
    Stats batcherStats;
    //printf("set option is %hhu\n",setOptions);
    //printf("option i is %hhu\n",option_i);

    if (setOptions & option_b) {
        batcher_sort(&stats, A, arrSize);
        batcherStats = stats;
        reset(&stats);
        //print_stats(&stats,"Batcher Sort",elements);
        //printSortedArray(A,arrSize);
    }

    if (setOptions & option_i) {
        insertion_sort(&stats, A, arrSize);
        print_stats(&stats, "Insertion Sort", arrSize);
        printSortedArray(A, elements, arrSize);
        reset(&stats);
    }
    if (setOptions & option_h) {
        heap_sort(&stats, A, arrSize);
        print_stats(&stats, "Heap Sort", arrSize);
        printSortedArray(A, elements, arrSize);
        reset(&stats);
    }
    if (setOptions & option_s) {
        shell_sort(&stats, A, arrSize);
        print_stats(&stats, "Shell Sort", arrSize);
        printSortedArray(A, elements, arrSize);
        reset(&stats);
    }

    if (setOptions & option_q) {
        quick_sort(&stats, A, arrSize);
        print_stats(&stats, "Quick Sort", arrSize);
        printSortedArray(A, elements, arrSize);
        reset(&stats);
    }
    if (setOptions & option_b) {
        print_stats(&batcherStats, "Batcher Sort", arrSize);
        printSortedArray(A, elements, arrSize);
        reset(&stats);
    }
    //if(setOptions & option_b){
    //    batcher_sort(&stats,A,arrSize);
    //    print_stats(&stats,"Batcher Sort",elements);
    //    printSortedArray(A,arrSize);
    //}

    //end:

    //printf("finished scanning through options\n");
    free(A);
    A = NULL;
}
