#include "insert.h"

#include <stdio.h>

void insertion_sort(Stats *stats, int *A, int length) {
    //sort values in A[0] through A[len(A) - 1]
    for (int i = 1; i < length; i++) {
        int j = i;
        int temp = move(stats, A[i]);
        while ((j >= 1) && (cmp(stats, temp, A[j - 1]) < 0)) {
            A[j] = move(stats, A[j - 1]);
            j -= 1;
        }
        A[j] = move(stats, temp);
    }
}
