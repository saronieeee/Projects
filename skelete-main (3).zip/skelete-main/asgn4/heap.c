#include "heap.h"

#include <stdbool.h>

int max_child(Stats *stats, int *A, int first, int last) {
    int left = 2 * first + 1;
    int right = 2 * first + 2;

    if (right <= last && (cmp(stats, A[left], A[right]) < 0)) {
        return right;
    }
    return left;
}

void fix_heap(Stats *stats, int *A, int first, int last) {
    bool done = false;

    while (2 * first + 1 <= last && !done) {
        int largest_child = max_child(stats, A, first, last);
        if (cmp(stats, A[first], A[largest_child]) < 0) {
            swap(stats, &A[first], &A[largest_child]);
            first = largest_child;
        } else {
            done = true;
        }
    }
}

void build_heap(Stats *stats, int *A, int first, int last) {
    if (last > 0) {
        for (int i = ((last - 1) / 2); i >= first; i--) {
            fix_heap(stats, A, i, last);
        }
    }
}

void heap_sort(Stats *stats, int *A, int n) {
    int first = 0;
    int last = n - 1;
    build_heap(stats, A, first, last);

    for (int i = last; i > first; i--) {
        swap(stats, &A[first], &A[i]);

        fix_heap(stats, A, first, i - 1);
    }
}
