#include "quick.h"

int partition(Stats *stats, int *A, int lo, int hi) {
    //use element hi as the pivot
    //divide the subarray into two partitions.
    int i = lo - 1;
    for (int j = lo; j < hi; j++) {
        //j takes values from lo to hi - 1
        if (cmp(stats, A[j], A[hi]) < 0) {
            i += 1;
            //swap elements i and j
            swap(stats, &A[i], &A[j]);
        }
    }
    i += 1;

    //swap the pivot and element i
    swap(stats, &A[i], &A[hi]);
    return i;
}

void quick_sorter(Stats *stats, int *A, int lo, int hi) {
    if (lo < hi) {
        int p = partition(stats, A, lo, hi);
        quick_sorter(stats, A, lo, p - 1);
        quick_sorter(stats, A, p + 1, hi);
    }
}

void quick_sort(Stats *stats, int *A, int n) {
    quick_sorter(stats, A, 0, n - 1);
}
