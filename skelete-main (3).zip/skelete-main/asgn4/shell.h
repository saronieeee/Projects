/*
* DO NOT MODIFY THIS FILE
*/

#ifndef __SHELL_H__
#define __SHELL_H__

#include "stats.h"

#include <stdint.h>

void shell_sort(Stats *stats, int *A, int n);

#endif
