#include "set.h"

Set set_empty(void) {
    Set x = 0x00;
    return x;
}

Set set_universal(void) {
    Set x = 0xFF;
    return x;
}

bool set_member(Set s, int x) {
    Set y = 0x01 << x;
    if (s & y) {
        return true;
    } else {
        return false;
    }
}

Set set_insert(Set s, int x) {
    Set y = 0x01 << x;
    return s | y;
}

Set set_remove(Set s, int x) {
    Set y = ~(0x01 << x);
    return s & y;
}

Set set_union(Set s, Set t) {
    return s | t;
}

Set set_intersect(Set s, Set t) {
    return s & t;
}

Set set_difference(Set s, Set t) {
    return s & ~t;
}

Set set_complement(Set s) {
    return ~s;
}
