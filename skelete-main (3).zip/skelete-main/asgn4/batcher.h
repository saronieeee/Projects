/*
* DO NOT MODIFY THIS FILE
*/

#pragma once

#include "stats.h"

void batcher_sort(Stats *stats, int *A, int n);
