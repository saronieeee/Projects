#include <fcntl.h>
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define OPTIONS "i:"
#define MAX     16
int main(int argc, char **argv) {
    //switch case for -i, -o, -d, -h
    //int opt;
    char *filein = NULL;
    int fileEntered = 0;
    /*
    while ((opt = getopt(argc, argv, OPTIONS)) != -1) {
        switch (opt) {
        case 'i': //sets file input
            filein = optarg;
	    fileEntered = 1;
            break;
        }
    }
	*/

    //printf("%d\n",argc);
    //printf("%s\n", argv[1]);
    if (argc == 2) {
        filein = argv[1];
        fileEntered = 1;
    }

    unsigned char buffer[MAX];
    unsigned char extra[1024];
    unsigned char values[MAX];
    int totalInput = 0;
    int extraChars = 0;
    unsigned char input;
    ssize_t numRead;
    int fd;
    int counter = 0;

    if (filein != NULL) {
        fd = open(filein, O_RDONLY);
        //printf("file has been opened\n");
        //printf("fd: %d\n",fd);
        //printf("filein: %s\n",filein);
        //printf("fileEntered: %d\n",fileEntered);
    }

forever:

    while (totalInput < MAX) {
        if (fileEntered == 1) {
            numRead = read(fd, buffer, sizeof(buffer));
            //printf("file has been read to numRead and added to buffer\n");
        } else {
            numRead = read(STDIN_FILENO, buffer, sizeof(buffer));
        }
        if (numRead < 0) {
            exit(1);
        }
        if (numRead == 0) {

            if (totalInput == 0 && numRead == 0) {
                exit(0);
            }

            printf("%07x0: ", counter);
            for (int i = 0; i < MAX; i++) {
                if (i < totalInput) {
                    printf("%02x", (unsigned char) values[i]);
                } else {
                    printf("  "); // Two spaces for characters not present
                }

                // Add a space between pairs
                if (i % 2 != 0) {
                    printf(" ");
                }
            }

            printf(" ");

            for (int i = 0; i < totalInput; i++) {
                if (values[i] < 32 || values[i] > 126) {
                    printf(".");
                } else {
                    printf("%c", values[i]);
                }
            }

            printf("\n");
            exit(0);
        }

        for (ssize_t i = 0; i < numRead; i++) {
            input = buffer[i];
            if (totalInput < MAX) {
                values[totalInput] = input;
                totalInput++;
            } else {
                extra[extraChars] = input;
                extraChars++;
            }
        }
    }

    //prints the buffed values to screen
    printf("%07x0: ", counter);
    for (int i = 0; i < totalInput - 1; i += 2) {
        printf("%02x%02x ", values[i], values[i + 1]);
    }

    printf(" ");

    for (int i = 0; i < MAX; i++) {
        if (values[i] < 32 || values[i] > 126) {
            printf(".");
        } else {
            printf("%c", values[i]);
        }
    }
    printf("\n");

    memcpy(values, extra, (unsigned long) extraChars);
    totalInput = extraChars;
    extraChars = 0;

    counter++;

    goto forever;

    if (fileEntered == 1) {
        close(fd);
    }
    return 0;
}
