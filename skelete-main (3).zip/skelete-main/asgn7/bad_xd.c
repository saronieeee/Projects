#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#define N printf
#define C N("%08zx: ", q)
#define M 16
size_t r, q;
void p(unsigned char *b, size_t r, size_t q) {
    C;
    for (size_t i = 0; i < M; i++)
        i < r ? N("%02x", b[i]) : N("  "), N((i % 2) ? " " : "");
    N(" ");
    for (size_t i = 0; i < r; i++)
        putchar(b[i] >= 32 && b[i] <= 126 ? b[i] : '.');
    N("\n");
}

int main(int c, char **v) {
    unsigned char b[M];
    size_t a;
    int f = c > 1 ? open(v[1], O_RDONLY) : 0;
    if (f < 0)
        exit(1);
    while ((a = (size_t) read(f, b + r, M - r)) > 0)
        if ((r += a) == M)
            p(b, r, q), q += r, r = 0;
    r > 0 ? (p(b, r, q), 0) : 0, close(f);
}
