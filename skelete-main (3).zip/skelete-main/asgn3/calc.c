#include "mathlib.h"
#include "messages.h"
#include "operators.h"
#include "stack.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define OPTIONS "hm"
int main(int argc, char *argv[]) {

    // taken from class lecture code on friday

    bool math_library = false;
    int opt;

    while ((opt = getopt(argc, argv, OPTIONS)) != -1) {
        switch (opt) {
        case 'h': printf(USAGE, argv[0]); break;
        case 'm': math_library = true; break;
        default: printf(USAGE, argv[0]); break;
        }
    }

    //start of forever loop (until user enters q)
    char expr[STACK_CAPACITY];
start:
    while (1) {

        fprintf(stderr, "> ");
        if (fgets(expr, 1025, stdin) == NULL) {
            // Handle end-of-file (e.g., Ctrl+D) to exit the program
            exit(0);
        }

        if (strcmp(expr, "\n") == 0) {
            fprintf(stderr, "\n");
            goto start;
        }

        if (strcmp(expr, " ") == 0) {
            fprintf(stderr, "\n");
            goto start;
        }

        stack_clear();
        char *saveptr;
        const char *token = strtok_r(expr, " ", &saveptr);

        //const binary_operator_fn (*math_operators)[256];
        bool bad = true;
        bool error = false;
        //char badstring = token[strlen(token)-1];
        while (token != NULL) {
            //printf("in token check\n");
            double value;
            if (parse_double(token, &value)) {
                // If the token is a number, push it onto the stack
                //printf("pushing to stack\n");
                stack_push(value);
                bad = false;

                if (stack_size >= STACK_CAPACITY) {
                    fprintf(stderr, ERROR_NO_SPACE, value);
                    stack_clear();
                    error = true;
                    break;
                }
            } else {
                binary_operator_fn binary_op
                    = binary_operators[(unsigned char) token[0]]; // Use character code as an index
                //printf("checking if binary\n");
                if (binary_op != NULL) {
                    if (apply_binary_operator(binary_op)) {

                    } else {
                        fprintf(stderr, ERROR_BINARY_OPERATOR);
                        error = true;
                        goto start;
                    }
                }

                //printf("checking if math_library is true or false\n");
                if (math_library == false) {
                    //printf("math_library is false, now checking if unary_op is null\n");
                    unary_operator_fn unary_op = (my_unary_operators)[(unsigned char) token[0]];
                    if (unary_op != NULL) {
                        //printf("in unary_op\n");
                        if (apply_unary_operator(unary_op)) {
                            bad = false;
                        } else {
                            fprintf(stderr, ERROR_UNARY_OPERATOR);
                            error = true;
                            goto start;
                        }
                    }

                } else { //using math.h operands
                    unary_operator_fn unary_op = (libm_unary_operators)[(unsigned char) token[0]];
                    if (unary_op != NULL) {
                        if (apply_unary_operator(unary_op)) {
                            bad = false;
                        } else {
                            fprintf(stderr, ERROR_UNARY_OPERATOR);
                            error = true;
                            goto start;
                        }
                    }
                }
            }
            if (bad == true) {
                if (strlen(&token[0]) > 1) {
                    fprintf(stderr, ERROR_BAD_STRING, token);
                    error = true;
                } else {
                    fprintf(stderr, ERROR_BAD_CHAR, token[0]);
                    error = true;
                }
            }

            token = strtok_r(NULL, " ", &saveptr);

        } // end of token check loop

        if (error == false) {
            stack_print();
            printf("\n");
        }
        stack_clear();
    } // end of forever while loop

    //printf("finished");
    return 0;
}
