#include "hangman_helpers.h"

bool string_contains_character(const char *s, char c) {
    for (int i = 0; i < (int) strlen(s); ++i) {
        if (s[i] == c) {
            return true;
        }
    }
    return false;
}
char read_letter(void) {
    char letter = ' ';
    scanf(" %c", &letter);
    if (letter == ' ' || letter == '\n') {
        scanf(" %c", &letter);
    }
    return letter;
}

bool is_lowercase_letter(char c) {
    if (c >= 'a' && c <= 'z') {
        return true;
    } else {
        return false;
    }
}

bool validate_secret(const char *secret) {

    if ((int) strlen(secret) > MAX_LENGTH) {
        printf("the secret phrase is over 256 characters\n");
        return false;
    }
    for (int i = 0; i < (int) strlen(secret); i++) {
        if (is_lowercase_letter(secret[i]) || secret[i] == ' ' || secret[i] == '-'
            || secret[i] == '\'') {

        } else {
            printf("invalid character: '%c'\n", secret[i]);
            printf("the secret phrase must contain only lowercase letters, spaces, hyphens, and "
                   "apostrophes\n");
            return false;
        }
    }
    return true;
}
