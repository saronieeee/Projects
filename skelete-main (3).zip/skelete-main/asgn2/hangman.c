#include "hangman_helpers.h"

int main(int argc, char *argv[]) {

    if (argc < 2) {
        printf("wrong number of arguments\n");
        printf("usage: ./hangman <secret word or phrase>\n");
        printf("if the secret is multiple words, you must quote it\n");
        exit(1);
    }

    char secretP[sizeof(argv[1])];
    strncpy(secretP, argv[1], sizeof(secretP));

    if (!validate_secret(secretP)) {
        exit(1);
    }

    int eliminated = 0;
    char wGuessed[MAX_LENGTH] = "";
    char hidden[MAX_LENGTH] = "";

    for (int i = 0; i < (int) strlen(secretP); i++) {
        for (int j = 0; j < (int) strlen(punctuation); j++) {
            if (secretP[i] == punctuation[j]) {
                strcat(hidden, &secretP[j]);
            }
        }
        strcat(hidden, "_");
    }

    char guess;
    while (1) {
        //sets up the main playing stage
        printf("%s", CLEAR_SCREEN);
        printf("%s\n\n", arts[eliminated]);
        printf("    Phrase: %s\n", hidden);
        printf("Eliminated: %s\n\n", wGuessed);

        //prompts user for a guess and checks if it has been usen yet
        guess = 'Z';
        while (is_lowercase_letter(guess) == false) {
            printf("Guess a letter: ");
            guess = read_letter();
            if (string_contains_character(wGuessed, guess)) {
                continue;
            }
        }

        //code that checks if guess is in secret phrase
        if (string_contains_character(secretP, guess)) {
            for (int i = 0; i < (int) strlen(secretP); i++) {
                if (secretP[i] == guess) {
                    strncpy(&hidden[i], &secretP[i], sizeof(hidden[i]));
                }
            }
        } else {
            eliminated = eliminated + 1;
            strcat(wGuessed, &guess);
        }

        //sorts wGuessed - inspired/learned by tutorialspoint
        char temp;
        for (int i = 0; i < ((int) strlen(wGuessed)) - 1; i++) {
            for (int j = i + 1; j < (int) strlen(wGuessed); j++) {
                if (wGuessed[i] > wGuessed[j]) {
                    temp = wGuessed[i];
                    wGuessed[i] = wGuessed[j];
                    wGuessed[j] = temp;
                }
            }
        }

        //checks if won or lost
        if (eliminated >= 6) {
            printf("%s", CLEAR_SCREEN);
            printf("%s\n\n", arts[eliminated]);
            printf("    Phrase: %s\n", hidden);
            printf("Eliminated: %s\n\n", wGuessed);

            printf("You lose! The secret phrase was: %s\n", secretP);
            break;
        }

        if (strcmp(hidden, secretP) == 0) {
            printf("%s", CLEAR_SCREEN);
            printf("%s\n\n", arts[eliminated]);
            printf("    Phrase: %s\n", hidden);
            printf("Eliminated: %s\n\n", wGuessed);

            printf("You win! The secret phrase was: %s\n", secretP);
            break;
        }
    }
}
