#include "names.h"

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define SEED 2023

int main(void) {
    typedef enum { SIDE, RAZORBACK, TROTTER, SNOUTER, JOWLER } Position;

    const Position pig[7] = {
        SIDE,
        SIDE,
        RAZORBACK,
        TROTTER,
        SNOUTER,
        JOWLER,
        JOWLER,
    };

    int positionScore[7] = { 0, 0, 10, 10, 15, 5, 5 };

    int num_players = 2;
    printf("Number of players (2 to 10): ");
    int scanf_result = scanf("%d", &num_players);

    if (scanf_result < 1 || num_players < 2 || num_players > 10) {
        fprintf(stderr, "Invalid number of players. Using 2 instead.\n");
        num_players = 2;
    }

    unsigned seed = 2023;
    printf("Random-number seed? ");
    scanf_result = scanf("%u", &seed);

    if (scanf_result < 1) {
        fprintf(stderr, "Invalid seed. Using 2023 instead.\n");
    }

    int scores[10] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

    int pTurn = 0;
    int rollIndex = 0;
    int rollIndexScore = 0;

    while (scores[0] < 100 || scores[1] < 100 || scores[2] < 100 || scores[3] < 100
           || scores[4] < 100 || scores[5] < 100 || scores[6] < 100 || scores[7] < 100
           || scores[8] < 100 || scores[9] < 100) {
        printf("%s\n", player_name[pTurn]);
        while (scores[pTurn] < 100) {
            rollIndex = rand() % 8;
            rollIndexScore = positionScore[rollIndex];
            if (pig[rollIndex] == SIDE) {
                printf("rolls %d, has %d\n", rollIndexScore, scores[pTurn]);
                break;
            } else {
                scores[pTurn] = scores[pTurn] + rollIndexScore;
                printf("rolls %d, has %d\n", rollIndexScore, scores[pTurn]);
            }
        }
        if (scores[pTurn] > 100) {
            break;
        }
        pTurn++;
        if (pTurn > num_players - 1) {
            pTurn = 0;
        }
    }
    printf("%s won!\n", player_name[pTurn]);
    return 0;
}
