#include "path.h"

#include "stack.h"
#include "vertices.h"

#include <stdlib.h>

struct path;
typedef struct path {
    uint32_t total_weight;
    Stack *vertices;

} Path;
Path *path_create(uint32_t capacity) {
    Path *p = (Path *) calloc(1, sizeof(Path));
    p->vertices = stack_create(capacity + 1);
    p->total_weight = 0;
    return p;
}

void path_free(Path **pp) {
    if (pp != NULL || *pp != NULL) {
        stack_free(&(*pp)->vertices);
        free(*pp);
        *pp = NULL;
    }
}

uint32_t path_vertices(const Path *p) {
    return stack_size(p->vertices);
}

uint32_t path_distance(const Path *p) {
    return p->total_weight;
}

void path_add(Path *p, uint32_t val, const Graph *g) {
    if (stack_empty(p->vertices)) {
        stack_push(p->vertices, val);
    } else {
        uint32_t last;
        stack_peek(p->vertices, &last);
        uint32_t weight = graph_get_weight(g, last, val);
        p->total_weight += weight;
        stack_push(p->vertices, val);
    }
}
uint32_t path_remove(Path *p, const Graph *g) {
    uint32_t lastV;
    if (stack_peek(p->vertices, &lastV)) {
        stack_pop(p->vertices, &lastV);
        if (path_vertices(p) > 0) {
            uint32_t nV;
            if (stack_peek(p->vertices, &nV)) {
                p->total_weight -= graph_get_weight(g, nV, lastV);
            }
        }
        return lastV;
    }
    return 0;
}

void path_copy(Path *dst, const Path *src) {
    if (dst == NULL || src == NULL) {
        return;
    }
    stack_copy(dst->vertices, src->vertices);
    dst->total_weight = src->total_weight;
}

void path_print(const Path *p, FILE *f, const Graph *g) {
    uint32_t num_vertices = path_vertices(p);

    if (num_vertices == 0) {
        fprintf(f, "\n");
        return;
    }

    fprintf(f, "Alissa starts at:\n");
    stack_print(p->vertices, f, graph_get_names(g));
    //fprintf(f,"%s\n",graph_get_vertex_name(g, START_VERTEX));
    fprintf(f, "Total Distance: %u\n", p->total_weight);
}
