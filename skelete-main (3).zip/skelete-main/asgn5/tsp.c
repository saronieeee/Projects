#include "graph.h"
#include "path.h"
#include "stack.h"
#include "vertices.h"

#include <getopt.h>
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define START_VERTEX 0
#define OPTIONS      "i:o:dh"
#define USAGE                                                                                      \
    "Usage: tsp [options]\n\n"                                                                     \
    "-i infile    Specify the input file path containing the cities and edges\n"                   \
    "             of a graph. If not specified, the default input should be\n"                     \
    "             set as stdin.\n\n"                                                               \
    "-o outfile   Specify the output file path to print to. If not specified,\n"                   \
    "             the default output should be set as stdout.\n\n"                                 \
    "-d           Specifies the graph to be directed.\n\n"                                         \
    "-h           Prints out a help message describing the purpose of the\n"                       \
    "             graph and the command-line options it accepts, exiting the\n "                   \
    "            program afterwards.\n"

void dfs(Graph *graph, uint32_t vertex, Path *path, Path *bPath) {

    //code figured out in Trish's LSS section on Thursday 11/9
    uint32_t num_vertices = graph_vertices(graph);
    graph_visit_vertex(graph, vertex);
    path_add(path, vertex, graph);

    for (uint32_t i = 0; i < num_vertices; ++i) {
        if (graph_visited(graph, i) != true && graph_get_weight(graph, vertex, i) != 0) {
            dfs(graph, i, path, bPath);
        }
    }

    if (path_vertices(path) == num_vertices) {
        if (path_distance(path) < path_distance(bPath) || path_distance(bPath) == 0) {
            path_copy(bPath, path);
        }
    }

    graph_unvisit_vertex(graph, vertex);
    path_remove(path, graph);
}

int main(int argc, char **argv) {
    //switch case for -i, -o, -d, -h
    int opt;
    bool directed = false;
    char *filename = NULL;
    char *fileout = NULL;
    FILE *infile = stdin;
    FILE *outfile = stdout;
    uint32_t num_vertices;
    while ((opt = getopt(argc, argv, OPTIONS)) != -1) {
        switch (opt) {
        case 'i':
            // sets the file to read from input file
            // requires a filename as an argument
            // the default file to read from is stdin

            // use optarg and atoi
            filename = optarg;
            break;

        case 'o':
            // sets the file to write to output file.
            // requires a filename as an argument
            // the default to file to write to is stdout
            fileout = optarg;
            break;
        case 'd':
            //treats all graphs as directed
            //if d is specified, (i,j) is added, but (j,i) wont
            directed = true;
            break;

        case 'h': fprintf(stdout, "%s", USAGE); exit(1);
        }
    }

    //reads the input
    if (filename != NULL) {
        infile = fopen(filename, "r");
        if (infile == NULL) {
            fprintf(stderr, "tsp:  error reading input file %s\n", filename);
            fprintf(stderr, "%s", USAGE);
            exit(1);
        }
    }

    if (fscanf(infile, "%u", &num_vertices) != 1) {
        fprintf(stderr, "tsp: error reading number of vertices\n");
        exit(1);
    }

    Graph *graph1 = graph_create(num_vertices, directed);

    //gets cities / locations listed
    char cities[PATH_MAX];
    for (uint32_t i = 0; i < num_vertices; i++) {
        fscanf(infile, " %[^\n]", cities);
        graph_add_vertex(graph1, cities, i);
    }

    // gets number of edges
    uint32_t num_edges;
    fscanf(infile, "%u", &num_edges);

    //error check (check if num edges is less than 0 and not one)
    if (num_edges < 0) {
        fprintf(stderr, "tsp:  must provide number of edges\n");
        exit(1);
    }

    for (uint32_t i = 0; i < num_edges; i++) {
        uint32_t start, end, weight;
        fscanf(infile, "%u %u %u", &start, &end, &weight);
        graph_add_edge(graph1, start, end, weight);
    }

    //setting all vertex indexes to false
    bool visited[graph_vertices(graph1)];
    for (uint32_t i = 0; i < graph_vertices(graph1); i++) {
        visited[i] = false;
    }

    //to close the file
    if (infile != stdin) {
        fclose(infile);
    }

    if (fileout != NULL) {
        outfile = fopen(fileout, "w");
        if (outfile == NULL) {
            fprintf(stderr, "Error opening output file\n");
            fprintf(stderr, USAGE);
            exit(1);
        }
    }

    //implementing the dfs function (finds the best path)
    Path *cPath = path_create(graph_vertices(graph1));
    Path *bPath = path_create(graph_vertices(graph1));

    dfs(graph1, START_VERTEX, cPath, bPath);

    bool home;
    if (graph_get_weight(graph1, path_vertices(bPath) - 1, 0) > 0) {
        home = true;
        //path_add(bPath, 0, graph1);
        //graph_add_vertex(graph1, graph_get_vertex_name(graph1, START_VERTEX), num_vertices);
        path_add(bPath, 0, graph1);
    }

    if (path_distance(bPath) == 0 || !home) {
        fprintf(outfile, "No path found! Alissa is lost!\n");
    } else {
        path_print(bPath, outfile, graph1);
    }

    //printf("\n");
    //graph_print(graph1);

    if (outfile != stdout) {
        fclose(outfile);
    }

    //free up memory
    path_free(&cPath);
    path_free(&bPath);
    graph_free(&graph1);
} // end of main function
